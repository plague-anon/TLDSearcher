=====
Usage
=====

To use TLDSearcher in a project::

    import tldsearcher
