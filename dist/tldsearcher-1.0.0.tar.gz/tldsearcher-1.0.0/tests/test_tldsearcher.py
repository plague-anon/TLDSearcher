#!/usr/bin/env python

"""Tests for `tldsearcher` package."""


import unittest

from tldsearcher import tldsearcher


class TestTldsearcher(unittest.TestCase):
    """Tests for `tldsearcher` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
