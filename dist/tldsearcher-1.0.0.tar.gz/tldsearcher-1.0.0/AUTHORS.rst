=======
Credits
=======

Development Lead
----------------

* plague <plague_anon@protonmail.com>


Contributors
------------

* imsi      | Anonops IRC #python

* Audreyr   | https://github.com/audreyr/cookiecutter
