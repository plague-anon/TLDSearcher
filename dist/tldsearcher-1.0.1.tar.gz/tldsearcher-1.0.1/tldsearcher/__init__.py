"""Top-level package for TLDSearcher."""

__author__ = """plague"""
__email__ = 'plague_anon@protonmail.com'
__version__ = '1.0.1'
