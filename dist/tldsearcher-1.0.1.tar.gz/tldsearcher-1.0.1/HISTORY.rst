=======
History
=======
* 1.0.1
    * Fixed 'Module not recognised' bug
    * Added start time to beginning of scan process
    * Fixed verbose mode not printing negative results
* 1.0.0
    * 1.0.0 full package release
